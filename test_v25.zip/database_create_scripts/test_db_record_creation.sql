INSERT INTO Location VALUES (null,"Turlock, Ca", 37.4947, 37.4947);

INSERT INTO User (email, password, first_name, last_name) VALUES ("caleb.allen@gmail.com",PASSWORD("testing123"),"Caleb","Allen");

INSERT INTO Photo (path,user_email,location) VALUES ("www.spotter.com/photos/thisone.jpg","caleb.allen@gmail.com",1);